let colors = ['#ffffff', '#a8e063', '#56ab2f'];
let circles = [];
let animals = [];
let sunX = 0;

function setup() {
    let canvas = createCanvas(600, 400);
    canvas.parent("p5-container");
    textAlign(CENTER, CENTER);
    textSize(20);
}

function draw() {
    background('#87CEEB'); // céu

    drawSun();
    drawGround();
    drawAnimals();

    // Círculos plantados
    for (let c of circles) {
        fill(c.color);
        noStroke();
        ellipse(c.x, c.y, c.size);
    }

    fill(0);
    text("Clique para plantar sementes", width / 2, 30);
    text("Aperte 'C' para limpar, 'A' para adicionar um animal", width / 2, height - 20);
}

function mousePressed() {
    if (mouseX >= 0 && mouseX <= width && mouseY >= 0 && mouseY <= height) {
        let newCircle = {
            x: mouseX,
            y: mouseY,
            size: random(10, 25),
            color: random(colors)
        };
        circles.push(newCircle);
    }
}

function keyPressed() {
    if (key === 'c' || key === 'C') {
        circles = [];
        animals = [];
    }
    if (key === 'a' || key === 'A') {
        animals.push({ x: random(50, width - 50), y: height - 60 });
    }
}

function drawGround() {
    fill('#228B22');
    rect(0, height - 50, width, 50);
}

function drawSun() {
    fill('#FFD700');
    sunX += 0.5;
    if (sunX > width + 50) sunX = -50;
    ellipse(sunX, 60, 80, 80);
}

function drawAnimals() {
    for (let a of animals) {
        drawCow(a.x, a.y);
    }
}

function drawCow(x, y) {
    fill(255);
    rect(x, y - 20, 40, 20); // corpo
    fill(0);
    ellipse(x + 10, y - 10, 5, 5); // olho
    fill(150);
    rect(x + 10, y, 20, 10); // pernas
}
