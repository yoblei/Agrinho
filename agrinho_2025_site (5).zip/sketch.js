let seeds = [];
let cows = [];
let sunX = 0;
let timeOfDay = "manha";
let colors = ['#8BC34A', '#A5D6A7', '#C5E1A5', '#DCEDC8'];

function setup() {
  let canvas = createCanvas(600, 400);
  canvas.parent("p5-container");
  textAlign(CENTER, CENTER);
  setInterval(() => {
    timeOfDay = timeOfDay === "manha" ? "tarde" : timeOfDay === "tarde" ? "noite" : "manha";
  }, 15000);
}

function draw() {
  drawSky();
  drawSunOrMoon();
  drawGround();

  // Sementes
  for (let s of seeds) {
    fill(random(colors));
    ellipse(s.x, s.y, 10, 10);
  }

  // Vaquinhas
  for (let cow of cows) {
    drawCow(cow.x, cow.y);
  }

  // Textos
  fill(0);
  textSize(16);
  text("🌱 Clique para plantar | 🐄 'A' = vaca | 🧹 'C' = limpar", width / 2, 20);
}

function mousePressed() {
  if (mouseY > 0 && mouseY < height) {
    seeds.push({ x: mouseX, y: mouseY });
  }
}

function keyPressed() {
  if (key === 'A' || key === 'a') {
    cows.push({ x: random(50, width - 50), y: height - 60 });
  }
  if (key === 'C' || key === 'c') {
    seeds = [];
    cows = [];
  }
}

function drawCow(x, y) {
  fill(255);
  rect(x, y - 20, 40, 20); // corpo
  fill(0);
  ellipse(x + 10, y - 10, 5); // olho
  fill(120);
  rect(x + 10, y, 20, 10); // pernas
}

function drawSky() {
  if (timeOfDay === "manha") {
    background('#87CEEB');
  } else if (timeOfDay === "tarde") {
    background('#FFB74D');
  } else {
    background('#2C3E50');
  }
}

function drawSunOrMoon() {
  if (timeOfDay !== "noite") {
    fill('#FFD700');
    ellipse((frameCount % width), 60, 60);
  } else {
    fill('#FFFACD');
    ellipse(width - 80, 60, 50);
  }
}

function drawGround() {
  fill('#4CAF50');
  rect(0, height - 50, width, 50);
}
