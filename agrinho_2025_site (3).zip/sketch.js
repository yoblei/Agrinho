let colors = ['#ffffff', '#a8e063', '#56ab2f'];
let circles = [];
let animals = [];
let sunX = 0;
let timeOfDay = "manha"; // manha, tarde, noite
let dicas = [
    "Plante árvores para preservar o solo.",
    "Use a água com sabedoria na irrigação.",
    "Evite queimada! Preserve a natureza.",
    "Composte restos orgânicos para adubar.",
    "Rotacione culturas para manter o solo saudável."
];
let dicaAtual = "";
let showDica = false;
let cowSound;

function preload() {
    soundFormats('mp3', 'ogg');
    cowSound = loadSound('https://upload.wikimedia.org/wikipedia/commons/4/47/Cow_Moo_1.mp3');
}

function setup() {
    let canvas = createCanvas(600, 400);
    canvas.parent("p5-container");
    textAlign(CENTER, CENTER);
    textSize(18);
    setInterval(changeTimeOfDay, 15000);
    setInterval(showRandomDica, 10000);
    createButton("Reiniciar").mousePressed(resetAll).parent("p5-container").style("margin-top", "10px");
}

function draw() {
    drawBackground();

    drawSun();
    drawGround();
    drawAnimals();

    for (let c of circles) {
        fill(c.color);
        noStroke();
        ellipse(c.x, c.y, c.size);
    }

    fill(0);
    text("Clique para plantar sementes", width / 2, 30);
    text("Aperte 'C' para limpar, 'A' para adicionar um animal", width / 2, height - 20);

    if (showDica) {
        fill(255, 255, 255, 220);
        rect(width / 2 - 200, height / 2 - 60, 400, 50, 10);
        fill(0);
        text(dicaAtual, width / 2, height / 2 - 35);
    }
}

function mousePressed() {
    if (mouseX >= 0 && mouseX <= width && mouseY >= 0 && mouseY <= height) {
        let newCircle = {
            x: mouseX,
            y: mouseY,
            size: random(10, 25),
            color: random(colors)
        };
        circles.push(newCircle);
    }
}

function keyPressed() {
    if (key === 'c' || key === 'C') {
        resetAll();
    }
    if (key === 'a' || key === 'A') {
        animals.push({ x: random(50, width - 50), y: height - 60 });
        if (cowSound.isLoaded()) {
            cowSound.play();
        }
    }
}

function resetAll() {
    circles = [];
    animals = [];
    dicaAtual = "";
    showDica = false;
}

function drawGround() {
    fill('#228B22');
    rect(0, height - 50, width, 50);
}

function drawSun() {
    if (timeOfDay !== "noite") {
        fill('#FFD700');
        sunX += 0.5;
        if (sunX > width + 50) sunX = -50;
        ellipse(sunX, 60, 80, 80);
    }
}

function drawAnimals() {
    for (let a of animals) {
        drawCow(a.x, a.y);
    }
}

function drawCow(x, y) {
    fill(255);
    rect(x, y - 20, 40, 20); // corpo
    fill(0);
    ellipse(x + 10, y - 10, 5, 5); // olho
    fill(150);
    rect(x + 10, y, 20, 10); // pernas
}

function drawBackground() {
    if (timeOfDay === "manha") {
        background('#87CEEB'); // azul claro
    } else if (timeOfDay === "tarde") {
        background('#FFA500'); // laranja
    } else {
        background('#001d3d'); // azul escuro
        fill('#f0e68c');
        ellipse(width - 60, 60, 60); // lua
    }
}

function changeTimeOfDay() {
    if (timeOfDay === "manha") {
        timeOfDay = "tarde";
    } else if (timeOfDay === "tarde") {
        timeOfDay = "noite";
    } else {
        timeOfDay = "manha";
    }
}

function showRandomDica() {
    dicaAtual = random(dicas);
    showDica = true;
    setTimeout(() => showDica = false, 5000);
}
